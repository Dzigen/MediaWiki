<?php
/** Fiji Hindi (Latin script) (Fiji Hindi)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

$namespaceNames = [
	NS_MEDIA            => 'saadhan',
	NS_SPECIAL          => 'khaas',
	NS_TALK             => 'baat',
	NS_USER             => 'sadasya',
	NS_USER_TALK        => 'sadasya_ke_baat',
	NS_PROJECT_TALK     => '$1_baat',
	NS_FILE             => 'file',
	NS_FILE_TALK        => 'file_ke_baat',
	NS_MEDIAWIKI_TALK   => 'Mediawiki_ke_baat',
	NS_TEMPLATE_TALK    => 'Template_ke_baat',
	NS_HELP             => 'madat',
	NS_HELP_TALK        => 'madat_ke_baat',
	NS_CATEGORY         => 'vibhag',
	NS_CATEGORY_TALK    => 'voibhag_ke_baat',
];
