<?php
/** Seediq (Taroko)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Amire80
 */

$fallback = 'zh-hant';
